from command_parser.clang_parse.clang_option_dict.clang_option_dict_base import ClangOptionDictBase


class ClangOptionDict_4_0_0(ClangOptionDictBase):
    pass