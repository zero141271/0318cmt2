from command_parser.option_filter_base import FilterBase

class StripFilter(FilterBase):
    def __init__(self, context=None):
        pass
    