class OptionContext(object):
    def __init__(self):
        self.__libs_paths = []
        self.__inc_system = []
        self.__sys_root = ''
        self.__include_sys_root = ''