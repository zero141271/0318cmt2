from command_parser.option_filter_base import FilterBase
class RanlibFilter(FilterBase):
    def __init__(self, context=None,) -> None:
        self.__context = context