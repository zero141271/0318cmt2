int main(){
    int* ptr=0;
    if(5+10 > 10){
        *ptr=10;
    }
}